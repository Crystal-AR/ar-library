//
//  Globals.cpp
//  OpenCV Tutorial
//
//  Created by Anton Belodedenko on 26/07/2012.
//  Copyright (c) 2012 computer-vision-talks.com. All rights reserved.
//

#include <iostream>

// control flags
bool computeObject = false;
bool detectObject = false;
bool trackObject = false;
