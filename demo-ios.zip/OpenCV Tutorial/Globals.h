//
//  Globals.h
//  OpenCV Tutorial
//
//  Created by Anton Belodedenko on 26/07/2012.
//  Copyright (c) 2012 computer-vision-talks.com. All rights reserved.
//

#ifndef OpenCV_Tutorial_Globals_h
#define OpenCV_Tutorial_Globals_h

// control flags
extern bool computeObject;
extern bool detectObject;
extern bool trackObject;

#endif
